# Detection obstacle  > 2025-10-18 1:13pm
https://universe.roboflow.com/victor-lauret/detection-obstacle-rao9o

Provided by a Roboflow user
License: CC BY 4.0

